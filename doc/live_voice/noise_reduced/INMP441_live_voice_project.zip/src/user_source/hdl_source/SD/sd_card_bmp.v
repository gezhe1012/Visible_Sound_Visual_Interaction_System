
module sd_card_bmp #(
    parameter integer CLK_FREQ_HZ       = 100_000_000,
    parameter [31:0]  SCAN_START_SECTOR = 32'd0,
    parameter [31:0]  SCAN_MAX_SECTOR   = 32'd131071,
    parameter [2:0]   SCAN_TARGET_COUNT = 3'd4,
    parameter integer KEY_EVENT_MODE  = 0, // 1: video-domain short-action toggles
    parameter integer AUTO_PLAY_SECONDS = 1,
    parameter integer WAIT_MELODY_END = 0, // only top science build enables this
    parameter integer LIVE_VOICE_PAGE = 0 // append a procedural page after five BMPs
)(
    input                       clk,
    input                       rst,
    input                       key_next,
    input                       key_auto,
    input                       melody_complete, // sticky video-domain level
    output [3:0]                state_code,
    input  [15:0]               bmp_width,
    input  [15:0]               bmp_height,
    output reg                  display_valid,

    // Video-domain transition handshake.  A new buffer is announced only
    // after its complete frame has reached SDRAM; it becomes current after
    // the fade controller returns transition_done_toggle.
    input                       transition_done_toggle,
    output reg                  transition_start_toggle,
    output reg [1:0]            transition_buf_idx,
    output [2:0]                transition_lesson_idx,

    input                       write_finish_toggle,
    output reg [1:0]            write_buf_idx,
    output reg [1:0]            disp_buf_idx,

    output                      write_req,
    input                       write_req_ack,
    input                       write_ready,
    output                      write_en,
    output [31:0]               write_data,
    output                      SD_nCS,
    output                      SD_DCLK,
    output                      SD_MOSI,
    input                       SD_MISO
);

wire key_next_press;
wire key_auto_press;

wire             sd_sec_read;
wire [31:0]      sd_sec_read_addr;
wire [7:0]       sd_sec_read_data;
wire             sd_sec_read_data_valid;
wire             sd_sec_read_end;
wire             bmp_data_wr_en;
wire [23:0]      bmp_data;
wire             sd_init_done;
// Local initialization qualification breaks the original long high-fanout
// sd_init_done -> scaler CE path. One startup clock only; no pixel/data delay.
reg bmp_init_ready;
always @(posedge clk or posedge rst) begin
    if(rst) bmp_init_ready<=0;
    else bmp_init_ready<=sd_init_done;
end
wire             bmp_ready;
wire             bmp_load_error;
wire             scan_done;
wire             scan_found_valid;
wire [31:0]      scan_found_sector;
wire [2:0]       scan_found_total;

reg              scan_start_pulse;
reg              load_start_pulse;
reg [31:0]       load_sector;
reg              scan_kicked;
reg              first_image_committed;
reg              auto_play_en;
reg [31:0]       auto_cnt;
reg [2:0]        img_found_count;
reg [2:0]        img_idx;              // lesson index, NOT a frame-buffer address
reg [2:0]        load_idx;
reg [1:0]        pending_buf_idx;      // 当前正在写入的目标缓冲区
reg [31:0]       img_sector0;
reg [31:0]       img_sector1;
reg [31:0]       img_sector2;
reg [31:0]       img_sector3;
reg [31:0]       img_sector4;
reg [2:0]        melody_done_sync;
reg              next_req_pending;
reg              load_busy;
reg              transition_pending;

// bmp_ready 先表示“源文件读取/送 FIFO 完成”；真正切显示要等 write_finish_toggle 同步后
reg              source_done_seen;
reg              source_started_seen;
reg              memory_done_seen;

// 同步 mem_clk 域的 write_finish_toggle
reg [2:0]        wrfin_tgl_sync;
wire             write_finish_pulse;
reg [2:0]        trans_done_tgl_sync;
wire             transition_done_pulse;

wire auto_tick;
wire [2:0] next_from_current;
wire auto_advance_allowed=(WAIT_MELODY_END==0) || img_idx!=3'd4 || melody_done_sync[2];

assign write_en   = bmp_data_wr_en;
assign write_data = {bmp_data[23:16], bmp_data[15:8], bmp_data[7:0], 8'b0};
assign auto_tick  = (auto_cnt == (CLK_FREQ_HZ * AUTO_PLAY_SECONDS - 1));
assign transition_lesson_idx = load_idx; // stable bundled payload until transition ack
wire [2:0] page_count=img_found_count+((LIVE_VOICE_PAGE!=0 && img_found_count==5) ? 3'd1 : 3'd0);
assign next_from_current = next_index_limited(img_idx, page_count);
assign write_finish_pulse = wrfin_tgl_sync[2] ^ wrfin_tgl_sync[1];
assign transition_done_pulse = trans_done_tgl_sync[2] ^ trans_done_tgl_sync[1];

generate if(KEY_EVENT_MODE==0) begin : g_physical_keys
key_press_debounce #(
    .CLK_FREQ_HZ (CLK_FREQ_HZ),
    .DEBOUNCE_MS (20)
) u_key_next (
    .clk        (clk),
    .rst        (rst),
    .button_in  (key_next),
    .press_pulse(key_next_press)
);

key_press_debounce #(
    .CLK_FREQ_HZ (CLK_FREQ_HZ),
    .DEBOUNCE_MS (20)
) u_key_auto (
    .clk        (clk),
    .rst        (rst),
    .button_in  (key_auto),
    .press_pulse(key_auto_press)
);
end else begin : g_key_events
    reg [2:0] next_sync,auto_sync;
    always @(posedge clk or posedge rst) begin
        if(rst) begin next_sync<=0; auto_sync<=0; end
        else begin
            next_sync<={next_sync[1:0],key_next};
            auto_sync<={auto_sync[1:0],key_auto};
        end
    end
    assign key_next_press=next_sync[2]^next_sync[1];
    assign key_auto_press=auto_sync[2]^auto_sync[1];
end endgenerate

function [2:0] next_index_limited;
    input [2:0] cur;
    input [2:0] count;
    begin
        if(count<2 || {1'b0,cur}+4'd1>={1'b0,count}) next_index_limited=0;
        else next_index_limited=cur+3'd1;
    end
endfunction

function [31:0] sector_lut;
    input [2:0] idx;
    begin
        case (idx)
            3'd0: sector_lut = img_sector0;
            3'd1: sector_lut = img_sector1;
            3'd2: sector_lut = img_sector2;
            3'd3: sector_lut = img_sector3;
            3'd4: sector_lut = img_sector4;
            default: sector_lut = img_sector0;
        endcase
    end
endfunction

function [1:0] next_buf_lut;
    input [1:0] cur_disp_buf;
    input       valid_now;
    begin
        if (!valid_now)
            next_buf_lut = 2'd0;                 // 首图固定写 buffer0
        else if (cur_disp_buf == 2'd0)
            next_buf_lut = 2'd1;
        else
            next_buf_lut = 2'd0;
    end
endfunction

always @(posedge clk or posedge rst) begin
    if (rst) begin
        wrfin_tgl_sync        <= 3'b000;
        trans_done_tgl_sync   <= 3'b000;
        melody_done_sync<=0; img_sector4<=0;
        scan_start_pulse      <= 1'b0;
        load_start_pulse      <= 1'b0;
        load_sector           <= 32'd0;
        scan_kicked           <= 1'b0;
        first_image_committed <= 1'b0;
        auto_play_en          <= 1'b0;
        auto_cnt              <= 32'd0;
        img_found_count       <= 3'd0;
        img_idx               <= 2'd0;
        load_idx              <= 2'd0;
        pending_buf_idx       <= 2'd0;
        write_buf_idx         <= 2'd0;
        disp_buf_idx          <= 2'd0;
        img_sector0           <= 32'd0;
        img_sector1           <= 32'd0;
        img_sector2           <= 32'd0;
        img_sector3           <= 32'd0;
        next_req_pending      <= 1'b0;
        load_busy             <= 1'b0;
        transition_pending    <= 1'b0;
        source_done_seen      <= 1'b0;
        source_started_seen   <= 1'b0;
        memory_done_seen      <= 1'b0;
        display_valid         <= 1'b0;
        transition_start_toggle <= 1'b0;
        transition_buf_idx      <= 2'd0;
    end else begin
        wrfin_tgl_sync      <= {wrfin_tgl_sync[1:0], write_finish_toggle};
        trans_done_tgl_sync <= {trans_done_tgl_sync[1:0], transition_done_toggle};
        melody_done_sync <= {melody_done_sync[1:0],melody_complete};
        scan_start_pulse <= 1'b0;
        load_start_pulse <= 1'b0;

        if (!sd_init_done) begin
            scan_kicked           <= 1'b0;
            first_image_committed <= 1'b0;
            auto_play_en          <= 1'b0;
            auto_cnt              <= 32'd0;
            img_found_count       <= 3'd0;
            img_idx               <= 2'd0;
            load_idx              <= 2'd0;
            pending_buf_idx       <= 2'd0;
            write_buf_idx         <= 2'd0;
            disp_buf_idx          <= 2'd0;
            img_sector0           <= 32'd0;
            img_sector1           <= 32'd0;
            img_sector2           <= 32'd0;
            img_sector3           <= 32'd0;
            img_sector4           <= 32'd0;
            next_req_pending      <= 1'b0;
            load_busy             <= 1'b0;
            transition_pending    <= 1'b0;
            source_done_seen      <= 1'b0;
            source_started_seen   <= 1'b0;
            memory_done_seen      <= 1'b0;
            display_valid         <= 1'b0;
            transition_start_toggle <= 1'b0;
            transition_buf_idx      <= 2'd0;
        end else begin
            // Keep five file addresses, but still only TWO SDRAM frame buffers.
            if (scan_found_valid) begin
                case (img_found_count)
                    3'd0: img_sector0 <= scan_found_sector;
                    3'd1: img_sector1 <= scan_found_sector;
                    3'd2: img_sector2 <= scan_found_sector;
                    3'd3: img_sector3 <= scan_found_sector;
                    3'd4: img_sector4 <= scan_found_sector;
                    default: ;
                endcase

                if (img_found_count < 3'd5)
                    img_found_count <= img_found_count + 3'd1;
            end

            // 记住 bmp_read 已经把源图送完 FIFO，但还不能切显示，得等整帧写完
            if (load_busy && !bmp_ready)
                source_started_seen <= 1'b1;
            if (load_busy && source_started_seen && bmp_ready)
                source_done_seen <= 1'b1;
            if (load_busy && write_finish_pulse)
                memory_done_seen <= 1'b1;

            // 整帧写完后通知 video 域启动转场，但暂不切换当前显示缓冲区。
            if (load_busy && source_done_seen && memory_done_seen && !bmp_load_error) begin
                load_busy             <= 1'b0;
                source_done_seen      <= 1'b0;
                source_started_seen   <= 1'b0;
                memory_done_seen      <= 1'b0;
                transition_pending    <= 1'b1;
                transition_buf_idx    <= pending_buf_idx;
                transition_start_toggle <= ~transition_start_toggle;
            end

            // video 域完成淡出、帧边界换缓冲和淡入后，再正式提交图片索引。
            if (transition_pending && transition_done_pulse) begin
                transition_pending    <= 1'b0;
                disp_buf_idx          <= pending_buf_idx;
                img_idx               <= load_idx;
                display_valid         <= 1'b1;
                first_image_committed <= 1'b1;
            end

            // Scan the configured target count (five in the science top).
            if (!scan_kicked && bmp_ready) begin
                scan_start_pulse      <= 1'b1;
                scan_kicked           <= 1'b1;
                first_image_committed <= 1'b0;
                auto_play_en          <= 1'b0;
                auto_cnt              <= 32'd0;
                img_found_count       <= 3'd0;
                img_idx               <= 2'd0;
                load_idx              <= 2'd0;
                pending_buf_idx       <= 2'd0;
                write_buf_idx         <= 2'd0;
                disp_buf_idx          <= 2'd0;
                next_req_pending      <= 1'b0;
                display_valid         <= 1'b0;
                load_busy             <= 1'b0;
                transition_pending    <= 1'b0;
                source_done_seen      <= 1'b0;
                source_started_seen   <= 1'b0;
                memory_done_seen      <= 1'b0;
                transition_start_toggle <= 1'b0;
                transition_buf_idx      <= 2'd0;
            end else begin
                // 忙的时候也只记 1 次“下一张”请求，不会累积成连跳两张
                if (key_next_press && scan_done && (img_found_count > 3'd0))
                    next_req_pending <= 1'b1;

                // 自动播放开/关
                if (key_auto_press && scan_done && (img_found_count > 3'd1)) begin
                    auto_play_en <= ~auto_play_en;
                    auto_cnt     <= 32'd0;
                end

                // 自动播放 1s 计数：只有当前没有写图任务时才计时
                if (scan_done && auto_play_en && display_valid && !load_busy && !transition_pending && first_image_committed && (img_found_count > 3'd1)) begin
                    if (auto_tick && auto_advance_allowed)
                        auto_cnt <= 32'd0;
                    else if(!auto_tick)
                        auto_cnt <= auto_cnt + 32'd1;
                end else begin
                    auto_cnt <= 32'd0;
                end

                // 首图自动加载到 buffer0
                if (scan_done && !first_image_committed && bmp_ready && !load_busy && !transition_pending && (img_found_count != 3'd0)) begin
                    load_idx         <= 2'd0;
                    load_sector      <= img_sector0;
                    pending_buf_idx  <= 2'd0;
                    write_buf_idx    <= 2'd0;
                    load_start_pulse <= 1'b1;
                    load_busy        <= 1'b1;
                    source_done_seen <= 1'b0;
                    source_started_seen <= 1'b0;
                    memory_done_seen <= 1'b0;
                    next_req_pending <= 1'b0;
                    auto_cnt         <= 32'd0;
                end
                // 手动下一张优先：写到“非当前显示”的另一块 buffer
                else if (scan_done && bmp_ready && display_valid && !load_busy && !transition_pending && next_req_pending && (img_found_count != 3'd0)) begin
                    load_idx         <= next_from_current;
                    if(LIVE_VOICE_PAGE!=0 && next_from_current==5) begin
                        // Reuse the committed buffer under a procedural RGB page.
                        // No fake SDRAM completion and no sixth file lookup.
                        pending_buf_idx<=disp_buf_idx;transition_buf_idx<=disp_buf_idx;
                        transition_pending<=1;transition_start_toggle<=~transition_start_toggle;
                    end else begin
                    load_sector      <= sector_lut(next_from_current);
                    pending_buf_idx  <= next_buf_lut(disp_buf_idx, display_valid);
                    write_buf_idx    <= next_buf_lut(disp_buf_idx, display_valid);
                    load_start_pulse <= 1'b1;
                    load_busy        <= 1'b1;
                    end
                    source_done_seen <= 1'b0;
                    source_started_seen <= 1'b0;
                    memory_done_seen <= 1'b0;
                    next_req_pending <= 1'b0;
                    auto_cnt         <= 32'd0;
                end
                // 自动播放下一张：同样写到“非当前显示”的另一块 buffer
                else if (scan_done && bmp_ready && display_valid && !load_busy && !transition_pending && auto_play_en && auto_tick && auto_advance_allowed && (img_found_count > 3'd1)) begin
                    load_idx         <= next_from_current;
                    if(LIVE_VOICE_PAGE!=0 && next_from_current==5) begin
                        pending_buf_idx<=disp_buf_idx;transition_buf_idx<=disp_buf_idx;
                        transition_pending<=1;transition_start_toggle<=~transition_start_toggle;
                    end else begin
                    load_sector      <= sector_lut(next_from_current);
                    pending_buf_idx  <= next_buf_lut(disp_buf_idx, display_valid);
                    write_buf_idx    <= next_buf_lut(disp_buf_idx, display_valid);
                    load_start_pulse <= 1'b1;
                    load_busy        <= 1'b1;
                    end
                    source_done_seen <= 1'b0;
                    source_started_seen <= 1'b0;
                    memory_done_seen <= 1'b0;
                    auto_cnt         <= 32'd0;
                end
            end
            // Keep displaying the committed frame after a rejected/failed load.
            if (bmp_load_error) begin
                load_busy <= 1'b0;
                source_done_seen <= 1'b0;
                source_started_seen <= 1'b0;
                memory_done_seen <= 1'b0;
                next_req_pending <= 1'b0;
            end
        end
    end
end

bmp_bilinear_reader bmp_read_m0(
    .clk                    (clk),
    .rst                    (rst),
    .ready                  (bmp_ready),

    .scan_start             (scan_start_pulse),
    .scan_start_sector      (SCAN_START_SECTOR),
    .scan_max_sector        (SCAN_MAX_SECTOR),
    .scan_target_count      (SCAN_TARGET_COUNT),
    .scan_done              (scan_done),
    .scan_found_valid       (scan_found_valid),
    .scan_found_sector      (scan_found_sector),
    .scan_found_total       (scan_found_total),

    .load_start             (load_start_pulse),
    .load_sector            (load_sector),

    .sd_init_done           (bmp_init_ready),
    .state_code             (state_code),
    .bmp_width              (bmp_width),
    .bmp_height             (bmp_height),
    .write_req              (write_req),
    .write_req_ack          (write_req_ack),
    .write_ready            (write_ready),
    .load_error             (bmp_load_error),
    .sd_sec_read            (sd_sec_read),
    .sd_sec_read_addr       (sd_sec_read_addr),
    .sd_sec_read_data       (sd_sec_read_data),
    .sd_sec_read_data_valid (sd_sec_read_data_valid),
    .sd_sec_read_end        (sd_sec_read_end),
    .bmp_data_wr_en         (bmp_data_wr_en),
    .bmp_data               (bmp_data)
);

sd_card_top sd_card_top_m0(
    .clk                    (clk),
    .rst                    (rst),
    .SD_nCS                 (SD_nCS),
    .SD_DCLK                (SD_DCLK),
    .SD_MOSI                (SD_MOSI),
    .SD_MISO                (SD_MISO),
    .sd_init_done           (sd_init_done),
    .sd_sec_read            (sd_sec_read),
    .sd_sec_read_addr       (sd_sec_read_addr),
    .sd_sec_read_data       (sd_sec_read_data),
    .sd_sec_read_data_valid (sd_sec_read_data_valid),
    .sd_sec_read_end        (sd_sec_read_end),
    .sd_sec_write           (1'b0),
    .sd_sec_write_addr      (32'd0),
    .sd_sec_write_data      (),
    .sd_sec_write_data_req  (),
    .sd_sec_write_end       ()
);

endmodule

module key_press_debounce #(
    parameter integer CLK_FREQ_HZ = 100_000_000,
    parameter integer DEBOUNCE_MS = 20
)(
    input  wire clk,
    input  wire rst,
    input  wire button_in,    // 默认：松开=1，按下=0
    output reg  press_pulse
);

localparam integer DEBOUNCE_CYCLES = (CLK_FREQ_HZ / 1000) * DEBOUNCE_MS;

reg button_sync0;
reg button_sync1;
reg button_stable;
reg [31:0] cnt;

always @(posedge clk or posedge rst) begin
    if (rst) begin
        button_sync0  <= 1'b1;
        button_sync1  <= 1'b1;
        button_stable <= 1'b1;
        cnt           <= 32'd0;
        press_pulse   <= 1'b0;
    end else begin
        button_sync0 <= button_in;
        button_sync1 <= button_sync0;
        press_pulse  <= 1'b0;

        if (button_sync1 == button_stable) begin
            cnt <= 32'd0;
        end else begin
            if (cnt >= DEBOUNCE_CYCLES - 1) begin
                if (button_stable && !button_sync1)
                    press_pulse <= 1'b1;
                button_stable <= button_sync1;
                cnt           <= 32'd0;
            end else begin
                cnt <= cnt + 32'd1;
            end
        end
    end
end

endmodule
